package dao;

import com.github.pagehelper.PageHelper;
import org.apache.log4j.Logger;
import org.junit.Test;
import util.HOFunctions;
import util.MybatisUtil;
import util.PageBean;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Optional;

/**
 * @author rxliuli
 * @date 2017/11/28 10:13
 */
public class SmbmsUserMapperTest {
  private static final Logger logger = Logger.getLogger(SmbmsUserMapperTest.class);

  @Test
  public void listByAll() throws Exception {
//    List<SmbmsUser> smbmsUserList = MybatisUtil.using(SmbmsUserMapper.class, SmbmsUserMapper::listByAll);
//    System.out.println(smbmsUserList);

//    Optional<List<SmbmsUser>> smbmsUserList = MybatisUtil.usingOptional(SmbmsUserMapper.class, SmbmsUserMapper::listByAll);
//    List<SmbmsUser> smbmsUsers = smbmsUserList.orElse(null);


//    List<SmbmsUser> smbmsUserList = MybatisUtil.using(sqlSession -> {
//      try {
//        SmbmsUserMapper smbmsUserMapper = sqlSession.getMapper(SmbmsUserMapper.class);
//        return smbmsUserMapper.listByAll();
//      } catch (Exception e) {
//        e.printStackTrace();
//        return new ArrayList<>();
//      }
//    });
//    System.out.println(HOFunctions.mkString(smbmsUserList, "\n"));

    //使用分页插件
    PageHelper.startPage(1, 5);
    Optional<List<SmbmsUser>> listOptional = MybatisUtil.usingOptional(SmbmsUserMapper.class, SmbmsUserMapper::listByAll);
    List<SmbmsUser> smbmsUserList = listOptional.orElse(null);
    PageBean<SmbmsUser> smbmsUserPageBean = new PageBean<>(smbmsUserList);
    System.out.println(smbmsUserPageBean.getPageSize());
  }

  @Test
  public void listByGenderAndBirthday() throws Exception {
    SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
    Date date = format.parse("2980-11-12");
    List<SmbmsUser> smbmsUserList = MybatisUtil.using(SmbmsUserMapper.class, smbmsUserMapper -> smbmsUserMapper.listByGenderAndBirthday(1, date));
    System.out.println(HOFunctions.mkString(smbmsUserList, "\n"));
  }

  @Test
  public void listByUserName() throws Exception {
    Optional<List<SmbmsUser>> listOptional = MybatisUtil.usingOptional(SmbmsUserMapper.class, smbmsUserMapper -> smbmsUserMapper.listByUserName("孙"));
    listOptional.ifPresent(smbmsUserList -> logger.info(HOFunctions.mkString(smbmsUserList, "\n")));
//    logger.info(listOptional.orElse(null));
  }

  @Test
  public void listByMap() throws Exception {
    HashMap<String, String> map = new HashMap<>();
    map.put("gender", "1");
    map.put("birthday", "1980-12-11");
    Optional<List<SmbmsUser>> listOptional = MybatisUtil.usingOptional(SmbmsUserMapper.class, smbmsUserMapper -> smbmsUserMapper.listByMap(map));
    System.out.println(listOptional);
  }

  @Test
  public void insert() throws Exception {
    SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
    SmbmsUser smbmsUser = new SmbmsUser(-1, "", "rxliuli", "123456", 2, simpleDateFormat.parse("2017-12-11"), "123456789", "幻想乡", 1, 1, simpleDateFormat.parse("2015-12-11"), 1, simpleDateFormat.parse("2014-12-11"));
    Optional<Integer> integer = MybatisUtil.usingOptional(SmbmsUserMapper.class, smbmsUserMapper -> smbmsUserMapper.insert(smbmsUser));
    System.out.println(integer.orElse(-1));

  }

  @Test
  public void deleteById() throws Exception {
    Optional<Integer> integer = MybatisUtil.usingOptional(SmbmsUserMapper.class, smbmsUserMapper -> smbmsUserMapper.deleteById(21));
    logger.info("受影响行数：" + integer.orElse(-1));
  }

  @Test
  public void findById() throws Exception {
    logger.info("用户：" + MybatisUtil.usingOptional(SmbmsUserMapper.class, smbmsUserMapper -> smbmsUserMapper.findById(20)));
  }

  @Test
  public void update() throws Exception {
    Optional<SmbmsUser> smbmsUserOptional = MybatisUtil.usingOptional(SmbmsUserMapper.class, smbmsUserMapper -> smbmsUserMapper.findById(20));
    if (smbmsUserOptional.isPresent()) {
      smbmsUserOptional.get().setUserCode("rxliuli");
      Optional<Integer> integer = MybatisUtil.usingOptional(SmbmsUserMapper.class, smbmsUserMapper -> smbmsUserMapper.update(smbmsUserOptional.get()));
      logger.info(integer.orElse(-1));
    }
  }
}
package dao;

import org.apache.log4j.Logger;
import org.junit.Test;
import util.MybatisUtil;

import java.util.List;
import java.util.Optional;

/**
 * @author rxliuli
 * @date 2017/11/28 16:47
 */
public class SmbmsBillMapperTest {
  private static final Logger logger = Logger.getLogger(SmbmsBillMapperTest.class);

  @Test
  public void listByAll() throws Exception {
    Optional<List<SmbmsBill>> listOptional = MybatisUtil.usingOptional(SmbmsBillMapper.class, SmbmsBillMapper::listByAll);
    logger.info("列表：" + listOptional);
  }

}
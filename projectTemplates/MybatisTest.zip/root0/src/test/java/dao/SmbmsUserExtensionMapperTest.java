package dao;

import org.apache.log4j.Logger;
import org.junit.Test;
import util.MybatisUtil;

import java.util.List;

/**
 * @author rxliuli
 * @date 2017/11/28 14:47
 */
public class SmbmsUserExtensionMapperTest {
  private static final Logger logger = Logger.getLogger(SmbmsUserExtensionMapperTest.class);

  @Test
  public void listByAll() throws Exception {
//    Optional<List<SmbmsUserExtension>> listOptional = MybatisUtil.usingOptional(SmbmsUserExtensionMapper.class, SmbmsUserExtensionMapper::listByAll);
//    System.out.println(listOptional);
    List<SmbmsUserExtension> smbmsUserExtensionList = MybatisUtil.getSession().getMapper(SmbmsUserExtensionMapper.class).listByAll();
    System.out.println(smbmsUserExtensionList);
  }

  @Test
  public void findById() throws Exception {
//    Optional<List<SmbmsUserExtension>> listOptional = MybatisUtil.usingOptional(SmbmsUserExtensionMapper.class, smbmsUserExtensionMapper -> smbmsUserExtensionMapper.findById(20));
//    System.out.println("列表：" + listOptional.orElse(null));
    List<SmbmsUserExtension> smbmsUserExtensionList = MybatisUtil.getSession().getMapper(SmbmsUserExtensionMapper.class).findById(20);
    System.out.println(smbmsUserExtensionList);
  }
}
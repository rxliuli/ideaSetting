package util;

import org.junit.Test;

/**
 * @author rxliuli
 * @date 2017/11/28 10:05
 */
public class MybatisUtilTest {
  @Test
  public void using() throws Exception {
  }
}